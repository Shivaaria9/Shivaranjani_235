var exp1=require ('express');

var app = exp1();

app.use(exp1.static('public'));// the name which we give in the 1st line. should be used here also.
app.get('/',function (req,res) //"/" is used to represent the default link
{
    // program using multiple routes to navigate 
   res.sendFile(__dirname +"/views/home.html"); // if we click the home link,it wont move forward. Becuz routing is given in the file.
});

app.get('/about',function (req,res)// to route the file 
{
     
   res.sendFile(__dirname +"/views/about.html"); // to find the path of the file
});

app.get('/contact',function (req,res)// to route the file 
{
     
   res.sendFile(__dirname +"/views/contact.html"); // to find the path of the file
});

app.get('/login',function (req,res)// to route the file 
{
     
   res.sendFile(__dirname +"/views/login.html"); // to find the path of the file
});
var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');