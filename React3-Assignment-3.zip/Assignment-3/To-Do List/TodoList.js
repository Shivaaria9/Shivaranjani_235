import { useState } from "react";
import DoList from './DoList';
import './Task.css';


function TodoList(){
   

    const [toArray, settoArray] = useState([]);
    const [str,setstr]= useState("");

    function addtoButton_click() {
      //if (str.trim() != ''){
        let newdata = [...toArray];      
        newdata.push({str:str});
        settoArray (newdata);
        setstr('');
//    }
}
   
    function deleteTask(index) {
        const updatedData = [...toArray];
        updatedData.splice(index, 1);
        settoArray(updatedData);
    };

    let resultarry = toArray.map((item,index) => {
        return  <div className="container">
        <table   className={ (index % 2 == 0?'table-success':'table-danger') }>
    <tr>
        
        <td>{item.str}</td>
        <td>
            <a href="javascript:void(0);" onClick= {() => deleteTask(index)}>
                <img  src="images/delete.png"  width="50"  />
            </a>   </td>
        </tr>
           
    </table>
    </div>
});

    return(
        <div className='task'>
            <h3 align="center">To-do List</h3>
        <input 
        type="text" 
        placeholder="Enter your To-Do" 
        value={str} 
        onChange={(e) => setstr(e.target.value)}  
        />
        <input 
        type="button" 
        className="btn btn-primary " 
        value="Add Task" 
        onClick={addtoButton_click} />
        {resultarry}
        <DoList toArraycount ={toArray.length} />
        </div>
    );
}

export default TodoList;