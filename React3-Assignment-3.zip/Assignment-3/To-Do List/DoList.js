

function DoList(props,onDelete){
    if(props.toArraycount == 0)     {
        return (
            <tr>
            <td align="center" colspan="4" style={{"color":"red"}}>
               
             </td>
           </tr>
      );
    }
    else    
    {
      return (<></>);
    }
}
       
export default DoList;