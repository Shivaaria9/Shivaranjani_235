import React from 'react';
//import EmpList from './EmpList';
//import EmpDetails from './EmpDetails';
//import DeptList from './DeptList'
import TodoList from './TodoList';

function App(){
    

  return (
    <>
    <TodoList/>
       </>
  );
}

export default App;
