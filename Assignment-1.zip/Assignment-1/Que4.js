var exp1=require ('express');
var app = exp1();
app.get('/',function (req,res)
{
   let str = "<h1 align='center'>Welcome Everyone.Server Started</h1>";
   str += "<hr/>";
   str += "<div>";
   str += "Employee Id: 10256<br/>";
   str += "Employee Name: Narasimha Rao<br/>";
   str += "Employee Job: Manager<br/>";
   str += "Employee Deptno: 10<br/>";
   str += "Employee Emailid: tnrao.trainer@gmail.com<br/>";
   str += "</div>";
   res.send(str);
});
var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');