var exp1=require ('express');
var app = exp1();
app.get('/',function (req,res)
{
    // program using html table
   let str = "<h1 align='center'>Welcome Everyone.Server Started</h1>";
   let proid= 10256;
   let proname= "LG Printer";
   let unitprice= 2500;
   let quantity= 3
   let totalamt=7500;

   str += `<style>
   table,td{
   border:2px solid black;
   }
   </style>
           <table >
           <tr >
           <td >Product Id</td>
           <td > ${proid}</td>
           </tr>
           <tr>
           <td>Product Name</td>
           <td> ${proname}</td>
           </tr>
           <tr>
           <td>Unit Price</td>
           <td> ${unitprice}</td>
           </tr>
           <tr>
           <td>Quantity</td>
           <td> ${quantity}</td>
           </tr>
           <tr>
           <td>Total Amount</td>
           <td> ${totalamt}</td>
           </tr>
    </table>`
   res.send(str);
});
var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');