var exp1=require ('express');
var app = exp1();
app.get('/',function (req,res)
{
    // program using variables and use of template literals
   let str = "<h1 align='center'>Welcome Everyone.Server Started</h1>";
   let empid= 10256;
   let empname= "Narasimha Rao";
   let empjob= "Manager";
   let deptno= 10;
   let emailid="tnrao.trainer@gmail.com";

   str += `<div>
           Employee Id: ${empid}<br/>
        Employee Name: ${empname}<br/>
   Employee Job: ${empjob}<br/>
   Employee Deptno:${deptno}<br/>
   Employee Emailid: ${emailid}<br/>
    </div>`
   res.send(str);
});
var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');