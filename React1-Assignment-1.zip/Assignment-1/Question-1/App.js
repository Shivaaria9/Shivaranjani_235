import React from 'react';
import DeptList from './DeptList';

function App(){

  return (
    <div>
      <h1>Student Information App</h1>
      <DeptList  />
    </div>
  );
};

export default App;
