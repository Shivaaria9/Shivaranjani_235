import React from 'react';

function DeptList() {

  let student = {sid:11,sname:"Aria",course: "Computer Science",age: 20,total: 95,};
  
  return (
    <div>
      <h2>Student Details</h2>
      <table border="2" width="400" cellspacing="0" cellpadding="5">
       
          <tr>
            <td><strong>Student ID:</strong></td>
            <td>{student.sid}</td>
          </tr>
          <tr>
            <td><strong>Name:</strong></td>
            <td>{student.sname}</td>
          </tr>
          <tr>
            <td><strong>Course:</strong></td>
            <td>{student.course}</td>
          </tr>
          <tr>
            <td><strong>Age:</strong></td>
            <td>{student.age}</td>
          </tr>
          <tr>
            <td><strong>Total:</strong></td>
            <td>{student.total}</td>
          </tr>
       
      </table>
    </div>
  );
};

export default DeptList;
