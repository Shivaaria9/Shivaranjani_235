import React from 'react';
//import DeptList from './DeptList';
import Doctordetail from './Doctordetail';

function App(){

  return (
    <div>
      <h1 align="center">Doctor Information</h1>
      <Doctordetail  />
    </div>
  );
}

export default App;
