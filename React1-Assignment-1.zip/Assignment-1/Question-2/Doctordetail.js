import React from 'react';

function Doctordetail(){
    let deptsArray = [
        { doctorId: 123, docname: "Akash", designation: "Cardiology",exp : 3, contactno :1234567897 },
        { doctorId: 120, docname: "Aria", designation: "Psychology",exp : 2, contactno :1234567897 },
        { doctorId: 1342, docname: "Ezra", designation: "General Surgon",exp : 5, contactno :1234567897 },
        { doctorId: 1977, docname: "Serkan", designation: "Cardiology",exp : 3, contactno :1234567897 }
    ];
     
    let arr1 = deptsArray.map((item) => {
        return <tr>
            <td>{item.doctorId}</td>
            <td>{item.docname}</td>
            <td>{item.designation}</td>
            <td>{item.exp}</td>
            <td>{item.contactno}</td>
        </tr>
    });
    return(
        <div >
            <table border="2" width="400" cellspacing="0" cellpadding="5" align='center'>
                <tr>
                    <th>Doctor ID</th>
                    <th>Doctor Name</th>
                    <th>Designation</th>
                    <th>Experience</th>
                    <th>Contact Number</th>
                </tr>

                {arr1}
            </table>
        </div>
    );
}

export default Doctordetail;