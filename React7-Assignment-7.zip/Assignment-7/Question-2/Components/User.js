import axios from "axios";
import { useState } from "react";

function User(){
    
 const [usersarray,setusersarray] =useState([]);
 
   
        let url="https://reqres.in/api/users";
      axios.get(url).then ((resData) =>{
         console.log(resData.data.data);
         setusersarray(resData.data.data);
      });

    

    let result = usersarray.map(item => 
        {
          return <tr>
              <td>{item.id}</td>
              <td><img src={item.avatar}/></td>
              <td>{item.first_name}-{item.last_name}</td>
          </tr>;
        });

  return (
    <div style={{"padding":"5px","textAlign":"center"}}>
   <h3>Manager Detail</h3>
   <hr/>
   
   <table border="2" cellSpacing="0" width="500">
    <tr>
    <th>ID</th>
    <th>Photo</th>
    <th>Name</th>
    </tr>
    {result}
   </table>
 
       </div>
  );
}

export default User;
