import React, {useState} from 'react';

function Register(){

    return(
        <div>
        <h3>Register</h3>
        </div>
    );
}

export default Register;