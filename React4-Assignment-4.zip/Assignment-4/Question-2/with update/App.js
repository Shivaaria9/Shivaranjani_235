import React from 'react';
import AjaxDemo2 from './AjaxDemo2';


function App(){
    

  return (
    <>
   <AjaxDemo2/>
       </>
  );
}

export default App;
