//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(Studentdb is database name)
mongoose.connect('mongodb://127.0.0.1:27017/studentdb');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var StudentModelSchema = new Schema(
    {   StudId : Number, 
        Studname : String, 	
        Studgroup  : String,
        Studaddress : String   }, 
    { versionKey: false  } );

// Create Model Object	
// "studs"   --- collection name in mongodb
var StudentModel = mongoose.model('studs', StudentModelSchema );

// Exporting DeptModel 
module.exports = StudentModel;




