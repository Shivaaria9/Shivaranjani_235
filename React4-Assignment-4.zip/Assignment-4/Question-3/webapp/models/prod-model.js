//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(Studentdb is database name)
mongoose.connect('mongodb://127.0.0.1:27017/demodb');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var ProductModelSchema = new Schema(
    {   prodid : Number, 
        prodname : String, 	
        prodprice  : Number,
        prodcatagory : String   }, 
    { versionKey: false  } );

// Create Model Object	
// "studs"   --- collection name in mongodb
var ProductModel = mongoose.model('products', ProductModelSchema );

// Exporting DeptModel 
module.exports = ProductModel;




