import axios from "axios";
import { useState } from "react";

function AjaxDemo4() {

    const [productArray, setproductArray] = useState([]);
    const [ProId, setProId] = useState("");
    const [ProName, setProName] = useState("");
    const [ProPrice, setProPrice] = useState("");
    const [ProCatagory, setProCatagory] = useState("");

    //view the product in table format
    function getProduct() {
        let url = "http://localhost:3005/api/prod";
        axios.get(url).then((resdata) => {
            setproductArray(resdata.data);
        });
    }

 //adding new product
    function addProduct() {
        let prodobj = {};
        prodobj.prodid = ProId;
        prodobj.prodname = ProName;
        prodobj.prodprice = ProPrice;
        prodobj.prodcatagory = ProCatagory;

        let url = "http://localhost:3005/api/prod";
        axios.post(url,prodobj).then((resdata) => {
            alert(resdata.data.status);
            getProduct();
        });

        clearFields();
    }

function updateProduct(sno){
    let updatedobj = {};
    updatedobj.prodid = ProId;
    updatedobj.prodname = ProName;
    updatedobj.prodprice = ProPrice;
    updatedobj.prodcatagory = ProCatagory;

        let url = "http://localhost:3005/api/prod"+sno;
        axios.put(url,updatedobj).then((resdata) => {
            alert(resdata.data.status);
            getProduct();
        });

        clearFields();
}

function selectClick(pno){
    const selectProduct = productArray.find((item)=> item.prodid === pno);

    if (selectProduct){
        setProId(selectProduct.prodid.toString());
        setProName(selectProduct.prodname);
        setProPrice(selectProduct.prodprice);
        setProCatagory(selectProduct.prodcatagory);
    }else {
        alert("Select Product is not available");
    }
}

function deleteClick(pno){
    let flag = window.confirm("Do you want to delete?");
    if (flag == false){
        return;
    }

    let url="http://localhost:3005/api/prod/"+pno;
    axios.delete(url).then ((resData) =>{
        alert(resData.data.status);
        getProduct();
   });
}

//reset the input field
    function clearFields() {
        setProId("");
        setProName("");
        setProPrice("");
        setProCatagory("");
    }
    let result = productArray.map(item => {
        return <tr>
            <td>{item.prodid}</td>
            <td>{item.prodname}</td>
            <td>{item.prodprice}</td>
            <td>{item.prodcatagory}</td>
            <td><a href="javascript:void(0);"
                onClick={() => deleteClick(item.prodid)}>
                <img src="images/delete.png" width="20" />
            </a>| <a href="javascript:void(0);"
                onClick={() => selectClick(item.prodid)}>
                    <img src="images/update.png" width="20" />
                </a></td>
        </tr>;
    });

    return (
        <div style={ {"border":"2px solid blue", "padding":"10px",
         "padding-bottom":"15px", "backgroundColor" : "lightyellow"}}>
            <h3>Product Details</h3>
            <hr />
            <input type="text" value={ProId} placeholder="Enter ID" onChange={(e) => setProId(e.target.value)} />
            <input type="text" value={ProName} placeholder="Enter Product Name" onChange={(e) => setProName(e.target.value)} />
            <input type="text" value={ProPrice} placeholder="Enter Product Price" onChange={(e) => setProPrice(e.target.value)} />
            <input type="text" value={ProCatagory} placeholder="Enter Product Catagory" onChange={(e) => setProCatagory(e.target.value)} />
            <hr />
            <input type="button" value="View Product" onClick={getProduct} />
            <input type="button" value="Add Product" onClick={addProduct} />
            <input type="button" value="Update Item" onClick={updateProduct} />
            <hr />
            <table border="2" cellSpacing="0" width="500">
                <tr>
                    <th>Product Id</th>
                    <th>Product Name</th>
                    <th>Product Price</th>
                    <th>Product ProCatagory</th>
                    <th>Actions</th>
                </tr>
                {result}
            </table>
        </div>
    );
}

export default AjaxDemo4;