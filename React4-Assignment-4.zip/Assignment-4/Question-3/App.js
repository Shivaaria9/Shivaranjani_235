import React from 'react';
import AjaxDemo4 from './AjaxDemo4';


function App(){
    

  return (
    <>
   <AjaxDemo4/>
       </>
  );
}

export default App;
