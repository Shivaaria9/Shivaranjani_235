import axios from "axios";
import { useState } from "react";
import './employee.css';
//import Records from './db_emp.json';
//without using any button the card will display once we run
function AjaxDemo3() {

    const [employeeArray, setemployeeArray] = useState([]);


    let url = "http://localhost:4100/emp";
    axios.get(url).then((resData) => {
        console.log(resData.data);
        setemployeeArray(resData.data);
    });

    let result = employeeArray.map(item => {
        return <div className="card">
            <img src={item.profile_image} /><br />
            <span>Id: {item.id}<br />
                Name: {item.employee_name}<br />
                Age: {item.employee_age}<br />
                Salary:{item.employee_salary}<br />
            </span>
        </div>
    });

    return (
        <div>

            <h3 style={{ "color": "red", "text-align": "center" }}>Ajax Program using JSON server</h3>
            <hr />

            {result}

        </div>
    );
}


export default AjaxDemo3;