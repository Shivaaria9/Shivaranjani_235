import React from 'react';
import AjaxDemo3 from './AjaxDemo3';


function App(){
    

  return (
    <>
   <AjaxDemo3/>
       </>
  );
}

export default App;
