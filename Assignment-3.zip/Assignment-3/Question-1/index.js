const express=require ('express');
const bodyParser = require("body-parser");
const userRouter = require('./user-routes');
const deptRouter = require('./dept-routes');
const proRouter = require('./product-routes');


var app = express();



app.use(bodyParser.urlencoded({extended:false}));
// the below will give the login page
//app.use(userRouter);
//if we use same routes in multiple page . to specify the specific route use the below
app.use("/user",userRouter); // to access the login page, change the href in home and login form
app.use("/dept",deptRouter);
app.use("/product",proRouter);
 app.set("view engine","ejs"); //connect the view engines
 
 app.get("/", function (req, res) {   
    res.render("home", {});
});


var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');