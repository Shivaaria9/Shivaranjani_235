const express = require("express");
//const bodyParser = require("body-parser");
const router = express.Router();


//router.use(bodyParser.urlencoded({extended:false}));
router.get("/order",function(req,res){
    let prodObj = {};

    prodObj.proArray= [
        { pid: 10, pname: "Chair", price: 500, quantity:3 ,catagory:"Furniture"},
        { pid: 20, pname: "Printer", price: 3500, quantity:2 ,catagory:"Electronics"},
        { pid: 30, pname: "Jeans", price: 500, quantity:3 ,catagory:"Clothing"},
        { pid: 40, pname: "Bluetooth", price: 1800, quantity:5 ,catagory:"Electronics"},
        { pid: 50, pname: "Sneckers", price: 500, quantity:3 ,catagory:"Shoes"}
    ];
    
    res.render("product",prodObj);
});

router.get("/GetProductById/:id", function(req,res){

    var proArray= [
        { pid: 10, pname: "Chair", price: 500, quantity:3 ,catagory:"Furniture"},
        { pid: 20, pname: "Printer", price: 3500, quantity:2 ,catagory:"Electronics"},
        { pid: 30, pname: "Jeans", price: 500, quantity:3 ,catagory:"Clothing"},
        { pid: 40, pname: "Bluetooth", price: 1800, quantity:5 ,catagory:"Electronics"},
        { pid: 50, pname: "Sneckers", price: 500, quantity:3 ,catagory:"Shoes"}
    ];
    
    let dno = parseInt(req.params.id);
    let dataObj = {};    
    dataObj.deptObj = proArray.find( item => item.pid == dno );

    res.render("showproduct", dataObj);
});

router.get("/productsByCategory", (req, res) => {

    var proArray= [
        { pid: 10, pname: "Chair", price: 500, quantity:3 ,catagory:"Furniture"},
        { pid: 20, pname: "Printer", price: 3500, quantity:2 ,catagory:"Electronics"},
        { pid: 30, pname: "Jeans", price: 500, quantity:3 ,catagory:"Clothing"},
        { pid: 40, pname: "Bluetooth", price: 1800, quantity:5 ,catagory:"Electronics"},
        { pid: 50, pname: "Sneckers", price: 500, quantity:3 ,catagory:"Shoes"}
    ];
    let pcatagory = req.query.pcatagory;
    let dataObj = {};
    dataObj.deptObj = proArray.find(product => product.catagory == pcatagory );
    res.render("productsByCategory",dataObj);  

});

router.get("/listproductbycatagory",(req,res) => {
    const proArray= [
        { pid: 10, pname: "Chair", price: 500, quantity:3 ,category:"Furniture"},
        { pid: 20, pname: "Printer", price: 3500, quantity:2 ,category:"Electronics"},
        { pid: 30, pname: "Jeans", price: 500, quantity:3 ,category:"Clothing"},
        { pid: 40, pname: "Bluetooth", price: 1800, quantity:5 ,category:"Electronics"},
        { pid: 50, pname: "Sneckers", price: 500, quantity:3 ,category:"Shoes"}
    ];
    const selectedCategory = req.query.category;
    const filteredProducts = proArray.filter(product => product.category === selectedCategory);
    res.render('productbycatagorgylist', { proArray: filteredProducts, category: selectedCategory });
  });


module.exports = router;