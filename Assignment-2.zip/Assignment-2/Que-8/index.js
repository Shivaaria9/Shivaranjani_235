var exp1=require ('express');
var bodyParser = require("body-parser");

var app = exp1();
app.use(bodyParser.urlencoded({extended:false}));
 app.set("view engine","ejs"); //connect the view engines
 
app.get('/',function (req,res) //"/" is used to represent the default link
{ 
    res.render("home",{}); 
});

app.get("/product",function(req,res){
    res.render("product",{totalamt:null});
});

app.post("/product",function(req,res){
    let proname=req.body.t1;
    let price=req.body.t2;
    let quan=req.body.t3;

    let totalamt = price * quan;
    res.render("product",{totalamt:totalamt});
});


var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');