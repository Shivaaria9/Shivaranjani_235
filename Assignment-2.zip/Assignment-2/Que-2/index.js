var exp1=require ('express');

var app = exp1();

 app.set("view engine","hbs"); //connect the view engines
app.get('/',function (req,res) //"/" is used to represent the default link
{ 
   //Scalar data
    let dataobj = {};
    dataobj.proid=10563;
    dataobj.proname="LG Printer";
    dataobj.unitpri=2500;

    // Array 
    dataobj.prodobj=["Hydrabad","Tamilnadu","Andra Pradesh"];

    //object- for 
    dataobj.deptobj={deptno:10, deptname:"Accounting", deptloc:"Kerala"};

    //Array Object
    dataobj.cusdata=[
    {"Name":"Alfreds Futterkiste","City":"Berlin","Country":"Germany"}, 
    {"Name":"Ana Trujillo Emparedados y helados","City":"México D.F.","Country":"Mexico"}, 
    {"Name":"Antonio Moreno Taquería","City":"México D.F.","Country":"Mexico"}, 
    {"Name":"Around the Horn","City":"London","Country":"UK"}, 
    {"Name":"B's Beverages","City":"London","Country":"UK"}, 
    {"Name":"Berglunds snabbköp","City":"Luleå","Country":"Sweden"}, 
    {"Name":"Blauer See Delikatessen","City":"Mannheim","Country":"Germany"}
]
    res.render("home",dataobj); // to access the data from the js file to ejs
});




var server=app.listen(3002,function(){});
console.log('This is My first app using express. You can view in URL: https://localhost:3002/');