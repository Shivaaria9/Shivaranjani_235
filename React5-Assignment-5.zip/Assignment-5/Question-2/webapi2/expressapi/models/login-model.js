var mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/studentdb');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var LoginModelSchema = new Schema({
    userId: { type: String, required: true },
    password: { type: String, required: true },
});

// Create Model Object	
// "studs"   --- collection name in mongodb
var LoginModel = mongoose.model('log', LoginModelSchema );

// Exporting DeptModel 
module.exports = LoginModel;
