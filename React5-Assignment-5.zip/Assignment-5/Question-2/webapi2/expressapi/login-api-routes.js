const express = require("express");
const LoginModel = require('./models/login-model');
const router = express.Router();

router.get("/Signin", async function (req, res) {

  let result = await LoginModel.find({}, { "_id": 0 });

  try {
      console.log("[Read All] - No. of  items get from database : " + result.length);
      res.send(result);
  }
  catch (error) {
      // sending error details to client
      res.status(500).send(error);    
  }
});

router.post("/Signin", async function (req, res) {

    const { userId, password } = req.body;

    try {
      const user = await LoginModel.findOne({ userId, password });
  
      if (user) {
        // Authentication successful
        return res.json({ success: true, message: "Login successful" });
      } else {
        // Invalid credentials
        return res.status(401).json({ success: false, message: "Invalid user ID or password" });
      }
    } catch (error) {
      console.error("Error during login:", error);
      return res.status(500).json({ success: false, message: "Internal server error" });
    }
  });
  
  module.exports = router;
  

