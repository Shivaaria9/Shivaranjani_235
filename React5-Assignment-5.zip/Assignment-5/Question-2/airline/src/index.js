import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router,Routes,Route,Link } from 'react-router-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import About from './Component/About';
import Login from './Component/Login';
import Student from './Component/Student';
import ProtectedRoute from './Component/ProtectedRoute';

const routing=(
  <Router>
     <h3 style={ { textAlign : "center"} }>Routing Implementation using React JS</h3>
    <hr/>
    <div>
      <Link to="/">Home</Link> | 
      <Link to="/About">About Us</Link> | 
      <Link to="/Login">Login</Link> |
      <Link to="/Student">Student Detail</Link>
      </div>
    <Routes>
      <Route path="/" element={<App/>} />
      <Route path="/About" element={<About/>}/>
      <Route path="/Login" element={<Login/>}/>
       <Route path="/Student" element={<ProtectedRoute  returnUrl="/Student">
          <Student />
        </ProtectedRoute>
      } />
       </Routes>
  </Router>
)

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
   {routing}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
