import './App.css';

function App() {
  return (
    <div className="App">
      <h3>Welcome to SPA User using React JS</h3>
      <img src="/images/banner.jpg" width="90%" height="250" alt="No Images"/>
    </div>
  );
}

export default App;
