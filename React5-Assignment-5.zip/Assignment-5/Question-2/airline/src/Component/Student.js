import axios from "axios";
import { useState } from "react";

function Student(){
    
 const [studentsarray,setstudentsarray] =useState([]);
 const [studid,setstudid] = useState("");
 const [studname,setstudname] = useState("");
 const [studgroup,setstudgroup] = useState("");
 const [studaddress,setstudadd] = useState("");
 const [editDeptno, setEditDeptno] = useState(null);

    function getDataClick(){
        let url="http://localhost:3005/api/studs";
      axios.get(url).then ((resData) =>{
        
         setstudentsarray(resData.data);
      });

    }

    function AddDataClick(){
      let studObj={};
      studObj.StudId=studid;
      studObj.Studname=studname;
      studObj.Studgroup=studgroup;
      studObj.Studaddress=studaddress;

      let url="http://localhost:3005/api/studs";
      axios.post(url,studObj).then ((resData) =>{
          alert(resData.data.status);
          getDataClick();
     });
     clearFields();
    }
    
    function selectdataclick(sno){
      const selectedStudent = studentsarray.find((student) => student.StudId === sno);

    if (selectedStudent) {
      // Set the selected student's details in the input fields
      setstudid(selectedStudent.StudId.toString());
      setstudname(selectedStudent.Studname);
      setstudgroup(selectedStudent.Studgroup);
      setstudadd(selectedStudent.Studaddress);
    } else {
      alert("Selected student not found!");
    }
  }
    

    function updatedataclick(sno){
      let updatedObj={};
      updatedObj.StudId=studid;
      updatedObj.Studname=studname;
      updatedObj.Studgroup=studgroup;
      updatedObj.Studaddress=studaddress;

      let url="http://localhost:3005/api/studs/"+sno;
      axios.put(url,updatedObj).then((resData) =>{
        alert(resData.data.status);
        getDataClick();
      });

      clearFields();

    }

    function clearFields(){
      setstudid("");
      setstudname("");
      setstudgroup("");
      setstudadd("");
    }

    function deletedataclick(sno){

      let flag = window.confirm("Are you sure want to delete?");
      if (flag == false) {
        return;
      }

      let url="http://localhost:3005/api/studs/"+sno;
      axios.delete(url).then ((resData) =>{
          alert(resData.data.status);
          getDataClick();
     });
    }

    let result = studentsarray.map(item => 
        {
          return <tr>
              <td>{item.StudId}</td>
              <td>{item.Studname}</td>
              <td>{item.Studgroup}</td>
              <td>{item.Studaddress}</td>
              <td><a href="javascript:void(0);"
              onClick={()=>deletedataclick(item.StudId)}>
                <img src="images/delete.png" width="20"/></a>
                | <a href="javascript:void(0);"
              onClick={()=>selectdataclick(item.StudId)}>
                <img src="images/update.png" width="20"/></a>
                </td>
          </tr>;
        });

  return (
    <div  style={ {"border":"2px solid blue", "padding":"10px", "padding-bottom":"15px", "backgroundColor" : "lightyellow"}}>
   <h3>CRUD OPERATION USING ROUTING</h3>
   <hr/>
    <input type="text" placeholder="Enter ID" value={studid} onChange={(e)=>setstudid(e.target.value)}/>
    <input type="text" placeholder="Enter Name" value={studname} onChange={(e)=>setstudname(e.target.value)}/>
    <input type="text" placeholder="Enter Course" value={studgroup} onChange={(e)=>setstudgroup(e.target.value)}/>
    <input type="text" placeholder="Enter Location" value={studaddress} onChange={(e)=>setstudadd(e.target.value)}/>
   <hr/>
   <input type="button" value="Get Data" onClick={getDataClick}/>
   <input type="button" value="Add Data" onClick={AddDataClick}/>
   <input type="button" value="Update Data" onClick={updatedataclick}/>
   <hr/>
   <table border="2" cellSpacing="0" width="500">
    <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Course</th>
    <th>Location</th>
    <th>Actions</th>
    </tr>
    {result}
   </table>
 
       </div>
  );
}

export default Student;
