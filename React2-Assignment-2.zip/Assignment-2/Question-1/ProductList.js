import { useState } from "react";

function ProductList() {
  const [pname, setPname] = useState("");
  const [price, setprice] = useState("");
  const [quantity, setquantity] = useState("");
  const [total, setTotal] = useState("");

  function Calculate() {
    let Producttotal = price * quantity;
    setTotal(Producttotal);
  }
  return (
    <div>
      <fieldset>
        <legend>Product Details</legend>
        Product Name : <input type="text" value={pname} onChange={ (e) => setPname(e.target.value)} />
                <br /> <br />
        Price :  <input type="text" value={price} onChange={ (e) => setprice(e.target.value)} />
                <br /> <br />
        Quantity : <input type="text" value={quantity} onChange={ (e) => setquantity(e.target.value)} />
                <br /> <br />
        <input type="button" onClick={Calculate} value=" Get Total" />
        <p>{total}</p>
      </fieldset>
    </div>
  );
}

export default ProductList;