import { useState } from "react";

function EmployeeList() {

    const [empArray, setempArray] = useState([]);

    const [empno, setempno] = useState("");
    const [empname, setempname] = useState("");
    const [job, setjob] = useState("");
    const [salary, setsalary] = useState("");
    const [deptno, setDeptno] = useState("");
    const [editempno, setEditempno] = useState(null);


    function getempButton_click() {
        let tempArray = [
            { empno: 10, empname: "Aakash", job: "Designing",salary:10000, deptno:23 },
            { empno: 20, empname: "Serra", job: "Marketing",salary:10000, deptno:34 },
            { empno: 30, empname: "Aria", job: "Accounting",salary:34000, deptno:334 },
            { empno: 40, empname: "Serkan", job: "Auditing",salary:23400, deptno:234 }
        ];

        setempArray(tempArray);
    }

    function addempButton_click() {

        let tempArray = [...empArray];       
        
        let empObj = {};
        empObj.empno = empno;
        empObj.empname = empname;
        empObj.job = job;
        empObj.salary = salary;
        empObj.deptno = deptno;
        tempArray.push(empObj);        

        setempArray(tempArray);


        setempno("");
        setempname("");
        setjob("");
        setsalary("");
        setDeptno("");
    }

    function editemp_click(dno) {
        // Set the current department details in the input fields for editing
        let empToEdit = empArray.find(item => item.empno === dno);
        setEditempno(dno);
        setempno(empToEdit.empno);//storing the value into setDeptno
        setempname(empToEdit.empname);
        setjob(empToEdit.job);
        setsalary(empToEdit.salary);
        setDeptno(empToEdit.deptno);
    }

    function updateempButton_click() {
        // Update the department details in the array
        let tempArray = [...empArray];
        let index = tempArray.findIndex(item => item.empno === editempno);

        tempArray[index] = { empno,empname, job, salary,deptno };

        setempArray(tempArray);

        // Clear the input fields and reset editDeptno
        setempno("");
        setempname("");
        setjob("");
        setsalary("");
        setDeptno("");
        setEditempno(null);
    }

    function deleteemp_click(dno) {

        let tempArray = [...empArray];    // cloning original array into temp array
        let index = tempArray.findIndex(item => item.empno == dno);
        tempArray.splice(index, 1);
        setempArray(tempArray);
    }


    let resultArray2 = empArray.map((item) => {
        return <tr>
            <td>   {item.empno}  </td>
            <td>   {item.empname}  </td>
            <td>   {item.job}  </td>
            <td>   {item.salary}  </td>
            <td>   {item.deptno}  </td>
            <td>
                <a href="javascript:void(0);" 
                   onClick={() => deleteemp_click(item.empno)}>Delete</a> 
           |
            <a href="javascript:void(0);" onClick={() => editemp_click(item.empno)}>
                        Edit
                    </a>
                   </td>
        </tr>
    });

    return (
        <>
            <h3>Working with State -- CRUD Operations on Array of Objects</h3>
            <hr />

            <input type="text" placeholder="Emp Number" value={empno} onChange={ (e) => setempno(e.target.value)} />
            <input type="text" placeholder="Emp Name" value={empname} onChange={ (e) => setempname(e.target.value)} />
            <input type="text" placeholder="Designation" value={job} onChange={ (e) => setjob(e.target.value)} />
            <input type="text" placeholder="Salary" value={salary} onChange={ (e) => setsalary(e.target.value)} />
            <input type="text" placeholder="Dept No" value={deptno} onChange={ (e) => setDeptno(e.target.value)} />
          
           
            <hr/>
            <input type="button" onClick={getempButton_click} value="Get Depts" />
            <input type="button" onClick={addempButton_click} value="Add Dept" />
            <input type="button" onClick={updateempButton_click} value="Update Dept"/>
            <hr />

            <table border="2" width="400" cellspacing="0" cellpadding="5">
                <tr>
                    <th>Emp Number</th>
                    <th>Emp Name </th>
                    <th>Designation</th>
                    <th>Salary</th>
                    <th>Dept Number</th>
                    <th>Actions</th>
                </tr>
                {resultArray2}
            </table>
        </>
    );
}

export default EmployeeList;