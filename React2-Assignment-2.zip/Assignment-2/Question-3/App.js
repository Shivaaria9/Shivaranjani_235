import React from 'react';
//import Loginform from './Loginform';
//import ProductList from './ProductList';
//import DeptList from './DeptList';
import EmployeeList from './EmployeeList';



function App(){

  return (
    <>
      <h1 align="center">Data Handling using useState</h1>
      <hr/>
     < EmployeeList/>

    </>
  );
}

export default App;
